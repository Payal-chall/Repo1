create Database assignment 

Use assignment

1.Installlation of Sql server

Sql server is known as structured querry language.This server can be operated in windows, mac . 
Windows such as 11(sql version 2022,2019),:Developer(full featured free edition),ssms; Sql server 10(version 2019 server),:Developer(full featured free edition),ssms;
windows 8 (sql server version 2016,2014),Express:free edition+ssms;8.1 version(2016,2014,2018) express:Free edition+ssms.
windows 7 +(Sql cversion2012) Express:free edition+ssms.

Step 1. to install Sql server

go to google ----- type MSSQL server---click on SQL server Downloads--open the downloads and Scroll down and select developer version-then download

Step 2 . open download file -once open select customer edition from developer edition page-again page open we can see media file location then click on install

step 3.once intallation button clicked--- file openSqls erver installation centere-> select intsallation-->sqls erver standalone installation---sql server setup file open----click on next-click on instalklation 
type--> new server installation one

step 4 -select sql server edition free and then click on 'NEXT';

step 5  accept the license aggreement and click on next.

step 6	 feature selection-->go to the option shown in table and then click on 'Database Engine'---> next

Step 7 Next--> instance configuration for sql server,instance id and name for gthe server to set-- two option:1. default, 2nd name instance so wee need to set Id and name in server-->click on next


Next step 8 - click on next--- again click on Next-- rachj to database engine configyuration or settings in server---> 2 option:1.windows authentication mode and other mix mode--- click on mix mode --set a password---
click on Add current user---> click on  next

Step 9 .ready to install ---click on below tab install---installation finish--- next step is to download sql server MS tools-connects database---will redirect to to microsoft sqls erver --click on download SSMS--go to download folder open the file and 
three options available : 
1. repair
2.install--- slect this
3.close--the close option

Step 10. Click on teh sqls erver installation studio and page opens up with object explore before that server connection will be asked related to server and password set by us in the step8 
-- then click on tab new query and start writing the querry.



Q 2.Basic structure of querry language

1. Craete table-table name

2. insert into table values

3.select*from table table_name

4. update Customer set City='San jose',Address='USA',State='South east',ZIP_code='35004' where Customer_Id=103; OR

update top(10) customer_Id set sales='400';

5.Alter table customer Add city char(),

6. Drop database databasename.

7. Contact_Number int

8. Name varchar()/ surname char(),

9.DOJ date,/Joining_date date time

10 Delete from customer_id where sales ='200';

11. Truncate table customer

12. EMP_ID INT NOT NULL  PRIMARY KEY





