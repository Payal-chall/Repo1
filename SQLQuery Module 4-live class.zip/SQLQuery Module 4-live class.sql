Create Database Module_4

Use Module_4


1.Create Table Orders(
Order_ID Int,
Order_date Date,
Amount int Not null,
Customer_ID Int,
Customer_name Varchar(300),
);
Insert into orders values
('1001','2020-1-19','300','1','ABC'),('1002','2021-06-15','200','2','DEF'),('1003','2020-5-20','100','3','GHI')

Select*from Orders;

Create Table Customer(
Customer_Id  Int,
First_Name varchar(200),
Last_Name varchar(200),
Email_ID varchar (100),
Address char (300),
City char (100),
State Char(30),
Zip_code char (20)
);

Insert into Customer values
('101','veena','Rao','veenarao@gmail.com','Thane west','Navi Mumabi','Maharashtra','400067'),('102','Heena','jaiswal','heenajaiswal@gmail.com','Borivali west','Mumbai','Maharashtra','400011'),
('103','Shilpa','Verma','shilpaverma@gmail.com','chandni chowk','Delhi','NCR','110022'),('104','poulami','das','poulamidas@gmail.com','Domjur East','Kolkata','West Bengal','700111'),
('105','Sudipa','Banerjee','sudipabanerjee@gmail.com','daspur_mednipur','Kolkata','West Bengal','700022');

Select*from Customer;
Select*from Orders;

2.Create a user-defined function, which will multiply the given number with 10

--Function Creation
Create function multiply (@val int) --input declartion
returns int -- output declartion
as
begin
	return @val * 10 --calculation
end

-- Calling Function
Select [dbo].[multiply] (120) as Result

-- Using function in a column

Select Amount as Actual_Amount, [dbo].[multiply] (Amount) as New_Amount from Orders



3.select
case
When 100=200 then'100 is less than 200'
when 100<200then'100 is equal to 200'
When 100>200 then'100 is greater than 200'
end
as result.

Select IIF(100>200,'yes it is true','no it is false') as result



