create database Module_2

Use Module_2

1. 
Create Table Customer(
Customer_Id  Int,
First_Name varchar(200),
Last_Name varchar(200),
Email_ID varchar (100),
Address char (300),
City char (100),
State Char(30),
Zip_code char (20)
);


2. 
Insert into Customer values
('101','veena','Rao','veenarao@gmail.com','Thane west','Navi Mumabi','Maharashtra','400067'),('102','Heena','jaiswal','heenajaiswal@gmail.com','Borivali west','Mumbai','Maharashtra','400011'),
('103','Shilpa','Verma','shilpaverma@gmail.com','chandni chowk','Delhi','NCR','110022'),('104','poulami','das','poulamidas@gmail.com','Domjur East','Kolkata','West Bengal','700111'),
('105','Sudipa','Banerjee','sudipabanerjee@gmail.com','daspur_mednipur','Kolkata','West Bengal','700022');

update customer set First_Name ='Gaurav' where Customer_Id=103;
update Customer set City='San jose',Address='USA',State='South east',ZIP_code='35004' where Customer_Id=103;

Select*from Customer;

3. select First_name,Last_Name from customer;

4. select *from Customer where First_Name LIKE 'G%' and city='San Jose';





