create database Module_3

Use Module_3

1. Create Table Orders(
Order_ID Int,
Order_date Date,
Amount int Not null,
Customer_ID Int,
Customer_name Varchar(300),
);

Insert into orders values
('1001','2020-1-19','300','1','ABC'),('1002','2021-06-15','200','2','DEF'),('1003','2020-5-20','100','3','GHI');

Select*from Orders;

Create Table Customers(
Customer_ID Int,
Customer_date Date,
Amount int Not null,
Customer_name Varchar(300),
Order_ID Int,
);

Insert into Customers values
('1001','2020-1-19','300','ABC','1001'),('1002','2021-06-15','200','DEF','1002'),('1003','2020-5-20','100','GHI','1003');

Select*from Customers;

2. Select Customers.Customer_ID from Customers 
INNER JOIN Orders 
ON Customers.customer_ID=Orders.order_id;

3. 
Select Customers.Customer_ID from Customers 
LEFT JOIN Orders 
ON Customers.customer_ID=Orders.order_id;
Select Customers.Customer_ID from Customers 
RIGHT JOIN Orders 
ON Customers.customer_ID=Orders.order_id;


4. Update Orders set Amount='100'where Order_ID=1003;

Select*from Orders;


