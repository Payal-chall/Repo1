Create database Module_5

Use Databse Module_5

Create Table Orders(
Order_ID Int,
Order_date Date,
Amount int Not null,
Customer_ID Int,
Customer_name Varchar(300),
);
Insert into orders values
('1001','2020-1-19','300','1','ABC'),('1002','2021-06-15','200','2','DEF'),('1003','2020-5-20','100','3','GHI')


1. 
select*from orders
order by Amount desc

2. Emp detail 1 & 2

Create table Employee_Detail1 (Emp_id int, Emp_Name Varchar(25), Emp_Salary int)

Create table Employee_Detail_2 (Emp_id int, Emp_Name Varchar(25), Emp_Salary int)

Insert into Employee_Detail1 values
(1,'Andrew',45000),
(2,'Bob',50000),
(3,'Kelly',75000)


Insert into Employee_Detail_2 values
(4,'Lily',55000),
(2,'Bob',50000),
(5,'Jasmine',35000)

3. UNION

select*from Employee_Detail1 
union 
Select*from Employee_Detail_2;

4. Intersect

select*from Employee_Detail1 
Intersect
Select*from Employee_Detail_2;

5. EXCEPT 

select*from Employee_Detail1 
except
Select*from Employee_Detail_2;


