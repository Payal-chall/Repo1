Create database Module_6

Use Module_6

VIEW :
Create Table Customer(
Customer_Id  Int,
First_Name varchar(200),
Last_Name varchar(200),
Email_ID varchar (100),
Address char (300),
City char (100),
State Char(30),
Zip_code char (20)
);

Insert into Customer values
('101','veena','Rao','veenarao@gmail.com','Thane west','Navi Mumabi','Maharashtra','400067'),('102','Heena','jaiswal','heenajaiswal@gmail.com','Borivali west','Mumbai','Maharashtra','400011'),
('103','Shilpa','Verma','shilpaverma@gmail.com','New city','San jose','CA','110022'),('104','poulami','das','poulamidas@gmail.com','Domjur East','Kolkata','West Bengal','700111'),
('105','Sudipa','Banerjee','sudipabanerjee@gmail.com','daspur_mednipur','Kolkata','West Bengal','700022');

Select*from Customer;


1. 

Creating view Customer_San_Jose
as
select*from customer where city='san jose'
viewing the view
select*from customer_san_jose

2. 

--Replace first_name as francis as  last name as sinha

a. begin tran
update customer set First_Name='Francis' where Last_Name='sinha'

select*from customer

Rollback Transaction

b. begin transaction
update customer set first_name='Alex' where Last_Name='sinha'
commit transaction


3. begin Try
select 100/0 as result
end try
begin catch
select  ERROR_MESSAGE() as warning
end catch
